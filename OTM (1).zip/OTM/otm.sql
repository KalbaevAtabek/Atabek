-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 23, 2022 at 05:17 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `login` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `login`, `password`, `created_at`, `updated_at`) VALUES
(1, 'diana2003', 'diana2003', '2022-12-17 08:42:48', '2022-12-17 08:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2022_12_17_123306_create_news_table', 1),
(5, '2022_12_17_123417_create_admins_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `name`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Turkiyaning Izmir shahridagi Ege universiteti bilan  Qoraqalpaq davlat universiteti orasida birgalikda faoliyat olib borish ishlari davom etmoqda', 'Bugungi kunda mamlakatimizda ta’lim yo’nalishini rivojlantirishga alohida e’tibor qaratilayotgani hech kimga sir emas. Ayniqsa, chet el oliy o’quv yurtlari bilan birgalikda faoliyat olib borish Memorandumi asosida o’quv-metodik, ilmiy-tadqiqot va tajriba almashish ishlari amalga oshirilmoqda.  Mana shunday oliy o’quv yurtlaridan biri Turkiyaning Izmir shahridagi Ege universiteti bo’lib, bu universitet Turkiyadagi eng katta va kuchli 3 universitetning biri hisoblanadi. QDU rektori prof A.Reymov boshchiligida bugungi kunda Qoraqalpoq davlat universiteti bilan birga ishlash va tajriba almashish ishlari yaxshi yo’lga qo’yilgan.  Shu asosda 2022-yil 18-28-noyabr kunlari Biologiya fakulteti dekani bilologiya fan doktori, professor Yakub Ametov Ege universitetida xizmat safarida bo’ldi. Xizmat safaridan ko’zlangan asosiy maqsad – Qoraqalpaq davlat universitetining  Biologiya fakulteti bilan Ege universitetining Qishloq-xo’jaligi fakulteti va Fan fakultetining Bilogiya bo’limi orasida tajriba alamshish, ilmiy-tadqiqot ishlarini mustahkamlash va rivojlantirish edi.      Xizmat safari mobaynida Biologiya fakulteti dekani prof. Yakub Ametov daslab Fan fakultetining  dekani prof. Dinçer AYAZ bilan uchrashdi. Uchrashuvda 2 fakultet dekanlari fakultetlar orasida “O’zaro kelishuv Memrandumi” imzoladi va oldindagi amalga oshiriladigan ishlar haqida kelishib olindi.  Xizmat safari mobaynida prof. Yakub Ametov Qishloq-xo’jaligi fakulteti dekani prof. Banu YÜCEL bilan uchrashdi. Uchrashuvda 2 fakultetning tuproqsunoslik va dorivor o’simliklar bo’limlari orasida ilmiy-tadqiqot ishlarining, shu bilan birgalikda ilmiy rejalar bo’yicha birga ishlashni yo’lga qo’yish, mustahkamlashva rivojlantirish bo’yicha olddagi ishlar haqida kelishildi. Shuningdek, Qishloq-xo’jaligi va Fan fakuletlarining kafedralari, tabiat muzeyi, ilmiy-tadqiqot laboratoriyalariva ularning faoliyati bilan yaqindan tanishdi.      Shu bilan birga Turkiyaning haqiqiy va takrorlanmas tabiat qo’yniga chiqib Egey dengizi va uning atrofining hayvonot va o’simliklar dunyosini ximoyalaydigan qo’riqxonalar bilan tanishdi.  O’z navbatida Yakub Ametov Fan fakultetining Biologiya bo’limi talaba yoshlari va professor o’qituvchilari “Orol va Orol bo’yi ekologiyasi” mavzusida seminat o’tkazdi. Shuningdek, qatnashuvchilarning Qoraqalpoq davlar universitetining Bilogiya fakulteti faoliyati bilan yaqindan tanishtirdi. Ikki universitet orasida amalga oshirilayotgan bu ishlar  kelajakda o’z natijasini berib, óz nátiyjesin berip Qoraqalpoq davlar universitetining  jahon arenasida old qatorlarga chiqishiga ishonamiz.', 'images/1671545384.png', '2022-12-20 09:09:44', '2022-12-20 09:09:44'),
(2, 'Ish beriuvchilar bilan uchrashuv', 'Joriy yilning 2-dekabr sanasida Sanoat texnologiyasi fakultetida Yengil sanoat buyumlari konstruksiyasini ishlash va texnologiyasi hamda Texnologik mashina va jihozlar ta’lim yoʻnalishlari boʻyicha ishlab chiqarish korxonalari raxbarlari bilan uchrashuv boʻlib oʻtti. Uchrashuvni fakultet dekani R.Qurbaniyazov ochib berdi va boshqarib bordi.   Uchrashuvdan asosiy maqsad Yengil sanoat buyumlari konstrukciyasini ishlash va texnalogiyasi (toʻqimachilik sanoati), Texnologik mashinalar va jihozlar (kimyo sanoati) ta’lim yoʻnalishlari oʻquv rejalarining ishlab chiqarish korhonalariga mosligini, 2022/2023 oʻquv yilida utilayotgan ixtisoslik fanlarining mavzulari zamonaviy ishlab chiqarish uskunalari talablariga mosligini, Yengil sanoat buyumlari konstrukciyasini ishlash va texnalogiyasi (toʻqimachilik sanoati) 2-kursdan e’tiboran korhonalarda amaliyotlarni tizimli oʻtkazishda va ixtisoslik fanlarning amaliy mashgʻulotlarni ishlab chiqarishda oʻtkazishni tashkillashtirishni muhokama qilish hamda Sanaot texnologiyasi kafedrasining professor-oʻqituvchilari tomonidan korhonadagi mavjud muammo va kamchiliklarni bartaraf etishda ilimiy va amaliy birga ishlash boʻyicha fikir almashish va takliflarni oʻrganib chiqishdan iborat.  Uchrashuvda fakultet dekani R.Qurbaniyazov Oʻzbekiston Respublikasi Prezidentining “Oʻzbekiston Respublikasi Oliy ta’lim tizimini 2030 – yilgacha rivojlantirish konsepsiyasini tasdiqlash toʻgʻrisida” 2019-yil 8-oktyabrdagi PF-5847-son Prezident Farmoni hamda Oʻzbekiston Respublikasi Prezidentining 2021-yil 16-iyundagi “Oliy ta’lim sohasidagi islohotlar natijadorligi hamda yangi oʻquv yiliga tayyorgarlik jarayonlari toʻgʻrisida” gi Oʻzbekiston Respublikasi Prezidentining oʻtkazilgan videoselektor majlisining 34-sonli bayonining ijrosini ta’minlash boʻyicha chora tadbirlar bilan tanishtirib oʻtdi.          Soʻng kun tartibidagi birinchi masala boʻyicha «Sanoat texnologiyasi» kafedrasi dotsenti, t.f.n. I.Turmanov Yengil sanoat buyumlari konstrukciyasini ishlash va texnalogiyasi (toʻqimachilik sanoati) oʻquv rejalarini ishlab chiqarish korhonalariga mosligin muhokama haqida aytib oʻtdi. Bu boʻyicha «ELITE STARS TEXTILE» M.Ch.J. rahbari M.Odambetov mutaxasislarni dasturchilik va chet tili fanlariga alohida etibor berish kerakligini va oʻquv rejada amalyotlarning koʻpligi talabalarning bilimini yanada ortirishini aytib oʻtdi.  Kun tartibidagi ikkinchi masala boʻyicha «Sanoat texnologiyasi» kafedrasi mudiri, t.f.f.d. A.Mambetsheripova  Texnologik mashinalar va jihozlar (kimyo sanoati) ta’lim yoʻnalishi oʻquv rejalarini ishlab chiqarish korhonalariga mosligi, bu boʻyicha qilinishi kerak boʻlgan vazifalarga toʻxtalib oʻtdi. muxokama haqida aytib oʻtdi Kun tartibidagi uchinchi masala boʻyicha «Sanoat texnologiyasi» kafedrasi dotsenti, t.f.d (Phd) S.Aytimbetov 2022-2023 oʻquv yilida oʻtilayotgan ixtisoslik fanlarining mavzulari zamonaviy ishlab chiqarish uskunalari talablariga mosligini muhokama qilishga chaqirdi. U oʻz soʻzida 60721200 – Yengil sanoat buyumlari konstrukciyasini ishlash va texnologiyasi (toʻqimachilik sanoati) ixtisoslik bitiruvchilarini yetishtirishda sifatli kadrlarni zamonaviy ishlab chiqarish korhonalariga toʻliq javob beradigan mutaxassislarni tayorlash boʻyicha «Kegeyli-Chimboy agroklaster» paxta tazalash zavodi texnik nazorat boʻlim boshligʻi A.Bayimbetov va «Agrosanoat majmosida xizmat koʻrsatish markazi» D.U.K. bosh mutaxasisi B.Sultanovlar amaliy mashgʻulotlarni oʻz korxonalarida oʻtish takliflarini bildirdi va tavsiyalar berildi.    Kun tartibidagi toʻrtinchi masala boʻyicha Yengil sanoat buyumlari konstrukciyasın ishlash va texnalogiyasi (toʻqimachilik sanoati) 2-kursdan boshlab korxonalarda amaliyotlarni tizimli oʻtkazishda va ixtisoslik fanlarning amaliy mashgʻulotlarni ishlab chiqarishda oʻtkazishni tashkillashtirish boʻyicha «Sanoat texnologiyasi» kafedrasi mudiri t.f.f.d (PhD) A.Mabetsheripova bayonot qildi. Bu boʻyicha “Shumanay ecotextil” A.J. korhona raxbari F.Esonov, «Kegeyli-Chimboy agroklaster» paxta tazalash zavodi tex. nazorat boʻlim boshligʻi A.Bayimbetov, «ELITE STARS TEXTILE» M.Ch.J. rahbari M.Odambetov, «Agrosanoat majmuida xizmat koʻrsatish markazi» D.U.K. bosh mutaxasisi B.Sultanov, «Qoʻngʻirot soda zavodi» A.J. mutaxasisi A.Qitaybekovalar amaliyotlarni va ixtisoslik fanlarning amaliy mashgʻulotlarni oʻz korhonalarida oʻtash kerakligini aytib shartnomalar tuzildi.  Kun tartibidagi beshinchi masala boʻyicha Fakultet dekani R.Qurbaniyazov «Sanaot texnologiyasi» kafedrasining proofessor-oʻqituvchilari tomonidan korhonadagi mavjud muammo va kamchiliklarni bartaraf etishda ilimiy va amaliy birga ishlashga chaqirdi. Uchrashuv soʻngida Ishlab chiqarish korhonalardan kelgan mehmonlar Sanoat texnologiyasi fakultetida tashkillashtirilgan ilmiy laboratoriyaga tashrif buyurdi. Laboratoriya boʻyicha bir-qancha takliflar berildi va «ELITE STARS TEXTILE» M.Ch.J. korxona rahbari M.Odambetov korhonasi tomonidan laboratoriya uchun iplarni qayta oʻrash mashinasini taqdim etishini aytib oʻtdi.', 'images/1671545446.png', '2022-12-20 09:10:46', '2022-12-20 09:10:46'),
(3, 'Amudaryo muhandislik texnikumida ochiq dars bo’lib o’tdi', 'Matematika fakulteti «Algoritmlash va dasturlash texnologiyalari» kafedrasi professor – o’qituvchilari Amudaryo muhandislik texnikumiga amaliy yordam berish va birga ishlash maqsadida xizmat safarida bo’ldi. «Algoritmlash va dasturlash texnologiyalari» kafedrasi mudiri B.Samandarov tomonidan Amudaryo muhandislik texnikumi «Kompyuter injineringi» ta’lim yo’nalishi o’quvchilariga ochiq dars o’tdi.  Ochiq dars davomida zamonaviy IT sohalaridan bir bo’lgan WEB dasturlash texnologiyalari bo’yicha tushuntirildi va freelanser bo’lib ishlash bugungi kunda ommalashayotgani haqida ma’lumotlar berib o’tildi. Mamlakatimizda IT sohasini rivojlantirish va ushbu sohaga qiziqishlarni orttirish maqsadida olib borilayotgan loyihalar, forumlar, musobaqalar va tadbirlar haqida qo’shimcha ma’lumotlar aytib o’tildi. Ochiq dars davomida o’quvchilar o’zlarining qiziqtirgan savollariga javoblar olishdi, ochiq darsda o’quvchilar faol qatnashishdi.', 'images/1671545504.png', '2022-12-20 09:11:44', '2022-12-20 09:11:44'),
(4, 'Ish beriuvchilar bilan uchrashuv davom etmoqda', 'Sanoat texnologiyasi fakultetida Neft va neftgazni qayta ishlash texnologiyasi va Texnologik mashina va jihozlar taʼlim yoʻnalishlari boʻyicha ishlab chiqarish korxonalari bilan uchrashuv boʻlib oʻtti. Uchrashuvga “Uz – Kor Gas Chemical” MCHJ qoʻshma korxonasi kadrlar boʻlimidan T.Yernazarov, O.Mambetlepesovlar qatnashdi. Uchrashuvni fakultet dekani R.Qurbaniyazov ochib berdi va boshqarib bordi. Uchrashuvdan asosiy maqsad 60721100 – Neft va neftgazni qayta ishlash texnologiyasi, 60720700 – Texnologik mashinalar va jihozlar (kimyo sanoati) taʼlim yoʻnalishlari oʻquv rejalarining ishlab chiqarish korxonalariga mosligini, 2022/2023 oʻquv yilida utilayotgan ixtisoslik fanlarining mavzulari zamonaviy ishlab chiqarish uskunalari talablariga mosligini, Neft va neftgazni qayta ishlash texnologiyasi va Texnologik mashinalar va jihozlar (kimyo sanoati) 2-kursdan eʼtiboran korxonalarda amaliyotlarni tizimli oʻtkazishda va ixtisoslik fanlarning amaliy mashgʻulotlarni ishlab chiqarishda oʻtkazishni tashkillashtirishni, «Neft va gaz texnologiyasi» kafedrasining 2-kurs bitiruvchi magistrlarini ishga joylashtirishni muhokama qilish hamda «Neft va gaz texnologiyasi» kafedrasining professor-oʻqituvchilari tomonidan korxonadagi mavjud muammo va kamchiliklarni bartaraf etishda ilimiy va amaliy birga ishlash boʻyicha fikir almashish va takliflarni oʻrganib chiqishdan iborat.    Uchrashuvni fakultet dekani R.Qurbaniyazov ochib berdi va boshqarib bordi. Dastlab u Oʻzbekiston Respublikasi Prezidentining “Oʻzbekiston Respublikasi Oliy taʼlim tizimini 2030-yilgacha rivojlantirish konsepsiyasini tasdiqlash toʻgʻrisida” 2019-yil 8 – oktabrdagi PF-5847-son Prezident Farmoni hamda Oʻzbekiston Respublikasi Prezidentining 2021-yil 16-iyundagi “Oliy taʼlim sohasidagi islohotlar natijadorligi hamda yangi oʻquv yiliga tayyorgarlik jarayonlari toʻgʻrisida” gi Oʻzbekiston Respublikasi Prezidentining oʻtkazilgan videoselektor majlisining 34-sonli bayonining ijrosini taʼminlash boʻyicha chora tadbirlar bilan tanishtirib oʻtdi. Soʻng kun tartibidagi birinchi masala boʻyicha «Neft va gaz texnologiyasi» mudiri T.Naubeyev 60721100 – Neft va neftgazni qayta ishlash texnologiyasi oʻquv rejalarini ishlab chiqarish korxonalariga mosligin muhokama haqida aytib oʻtdi. Bu boʻyicha “Uz – Kor Gas Chemical” MCHJ qoʻshma korxonasi kadrlar boʻlimi boshligʻi Mambetlepesov Oralbay mutaxasislarni dasturchilik va chet tili fanlariga aloxida etibor berish kerakligini va oʻquv rejada amalyotlarning koʻpligi talabalarning bilimini yanada ortirishini aytib oʻtdi. Kun tartibidagi ikkinchi masala boʻyicha «Sanoat texnologiyasi» kafedrasi mudiri, t.f.f.d. A.Mambetsheripova 60720700 – Texnologik mashinalar va jixozlar (kimyo sanoati) taʼlim yoʻnalishi oʻquv rejalarini ishlab chiqarish korhanalariga mosligi, bu boʻyicha qilinishi kerak boʻlgan vazifalarga toʻxtalib oʻtdi. muxokama haqida aytib oʻtdi Kun tartibidagi uchinchi masala boʻyicha «Neft va gaz texnologiyasi» kafedrasi dotsenti, t.f.f.d (PhD) N.Yusupova 2022-2023 oʻquv yilida oʻtilayotgan ixtisoslik fanlarining mavzulari zamonaviy ishlab chiqarish uskunalari talablariga mosligini muxakama qilishga chaqirdi. U oʻz soʻzida 60721100 – Neft va neftgazni qayta ishlash texnologiyasi ixtisoslik bitiruvchilarini yetishtirishda sifatli kadrlarni zamonaviy ishlab chiqarish korxonalariga toʻliq javob beradigan mutaxassislarni tayorlash boʻyicha “Uz – Kor Gas Chemical” MCHJ qoʻshma korxonasi kadrlar boʻlimidan Yernazarov Tursinbay, Mambetlepesov Oralbaylar amaliy mashgʻulotlarni oʻz korxonalarida oʻtish takliflarini bildirdi va tavsiyalar berildi va bitkazuvchi talabalar oʻrtasida har oyning 10 – sanasida korxona va kafedra tomonidan mutaxassisilik fanlardan tuzilgan testlardan test sinovlarini topshirish boʻyicha tavsiyalar berdi. Test sinovlaridan yaxshi va aʼlo darajada topshirgan talabarni korxonaga suhbat asosida ishga olishligin aytib oʻtdi.    Neft va neftgazni qayta ishlash texnologiyasi va Texnologik mashinalar va jixozlar (kimyo sanoati) 2-kursdan eʼtiboran korxonalarda amaliyotlarni tizimli oʻtkazishda va ixtisoslik fanlarning amaliy mashgʻulotlarni ishlab chiqarishda oʻtkazishni tashkillashtirish boʻyicha «Sanoat texnologiyasi» kafedrasi mudiri t.f.d (PhD) A.Mambetsheripovaning va «Neft va gaz texnologiyasi» mudiri T.Naubeyevning bayonoti qildi Bu boʻyicha “Uz – Kor Gas Chemical” MCHJ qoʻshma korxonasi kadrlar boʻlimidan Yernazarov Tursinbay, Mambetlepesov Oralbaylar amaliyotlarni va ixtisoslik fanlarning amaliy mashgʻulotlarni oʻz korxonalarida oʻtash kerakligini aytib shartnomalar tuzildi. Kun tartibidagi beshinchi masala boʻyicha Fakultet dekani R.Qurbaniyazov «Neft va gaz texnologiyasi» kafedrasining professor-oʻqituvchilari tomonidan korxonadagi mavjud muammo va kamchiliklarni bartaraf etishda ilimiy va amaliy birga ishlashga chaqirdi. Kun tartibidagi oltinchi masala boʻyicha «Neft va gaz texnologiyasi» kafedrasining 2-kurs bitiruvchi magistrlarini ishga joylashtirish boʻyicha (“Uz – Kor Gas Chemical” MCHJ qoʻshma korxonasi kadrlar boʻlimidan Yernazarov Tursinbay, Mambetlepesov Oralbaylar (“Uz – Kor Gas Chemical” MCHJ qoʻshma korxonasitomoni joriya qilinib borilayoigan boʻsh ish oʻrinlari toʻgʻrisida va ularda qanday qilib qatnashish boʻyicha oʻz koʻrsatmalarini berdi.', 'images/1671545559.png', '2022-12-20 09:12:39', '2022-12-20 09:12:39'),
(5, '10-DEKABR – O‘ZBEKISTON RESPUBLIKASI DAVLAT MADHIYASI QABUL QILINGAN KUN', 'Bugun O‘zbek filologiyasi fakulteti professor-o‘qituvchilari va talaba yoshlari davlatimiz madhiyasi sadolari ostida yangi kunni kutib oldi. Madhiyamizning har bir chuqur ma’noga ega satri, mardonavor va sohir ohangi bizni sehrlab qo‘yadi, qalbimizda Vatanimizdan faxrlanish, shukronalik va ishonch hissini jo‘sh urdiradi.  Davlat ramzlari mamlakatimiz suvereniteti va mustaqilligini ifodalovchi, xalqimizning shon-u shavkati, g‘ururi, or-nomusi, tarixiy xotirasi va orzu-umidlarini o‘zida mujassam etuvchi muqaddas timsollardir. Shu bois mustaqillikning ilk kunlaridan xalqimizning ozodlik, hurlik singari eng buyuk orzu-intilishlarini, ma’naviy qadriyatlarini ifodalovchi, Vatanimiz mustaqilligini mustahkamlash, yurtga sadoqat, bunyodkorlik va yaratuvchanlikka undovchi Bosh qo‘shiqni qabul qilishga asosiy e’tibor qaratildi.  1992-yil 10-dekabrda “O‘zbekiston Respublikasining Davlat madhiyasi to‘g‘risida”gi qonun imzolandi. Mazkur qonunda belgilanganidek, madhiyamiz davlat suverenitetining ramzi hisoblanadi, unga zo‘r ehtirom bilan qarash har bir fuqaroning vatanparvarlik burchidir. 2010-yil 24-dekabrda mazkur qonunga kiritilgan o‘zgartishga ko‘ra, fuqarolarimiz, shuningdek, mamlakatimizda bo‘lib turgan boshqa shaxslar madhiyamizni hurmat qilishlari shart ekanligi belgilab qo‘yildi.  O‘zbekiston Qahramoni, xalq shoiri Abdulla Oripov she’ri, O‘zbekiston xalq artisti, atoqli kompozitor Mutal Burhonov musiqasi asosida yaratilgan madhiyamizda musaffo osmonimiz, baxtli va farovon hayotimiz, xalqimizning asriy orzulari, kelajakka yorug‘ umidi va mustahkam ishonchi teran ifodalangan.  Davlatimiz madhiyasi qudratli kuchga ega. Ona Vatanini sevgan, o‘zi tug‘ilib o‘sgan yurtga o‘zini daxldor deb bilgan har bir kishi uning qudratiyu zalvorini his qilishi shubhasiz.', 'images/1671545601.png', '2022-12-20 09:13:21', '2022-12-20 09:13:21'),
(6, 'Bitiruvchi talabalar bilan uchrashuv', 'Bugun O‘zbek filologiyasi fakultetida Xalq ta’lim vazirligi xodimlari va bitiruvchi talabalar bilan uchrashuv bo‘lib o‘tdi. Uchrashuvning asosiy maqsadi yosh bitiruvchilarni hozirdan ish joylariga biriktirish, ularni tegishli yo‘nalishlar bo‘yicha ishga joylashtirish hamda hozirda shahar va tuman  maktablarida o‘zbek tili, turkman tili va qozoq tili fanlaridan vakant soatlar va vakant o‘rinlar uchun ishga joylashish uchun shartnoma tuzishdan iborat bo‘ldi.   Bundan tashqari xalq ta’lim bo‘limi mudirlari o‘zlarida mavjud ehtiyojni bildirdilar va shu yerning o‘zida bitiruvchi bosqich talabalari bilan suhbatlashib, ularga mavjud vakant joylarni taklif qildilar. Hozirgi kunda Xalq ta’lim vazirligining xt.uz.edu.uz saytida shahar va tuman maktablaridagi bo‘sh ish o‘rinlari bo‘yicha ma’lumotlar joylashtirilganligini va shu bo‘yicha ham ish bilan ta’minlanish imkoniyati borligini aytib o‘tdilar.  Bitiruvchilarni ishga joylashtirish bo‘yicha umuman yangicha yondoshuv asosida uchrashuv tashkil etilishi ikki tomon uchun ham juda foydali bo‘ldi.', 'images/1671545706.png', '2022-12-20 09:15:06', '2022-12-20 09:15:06');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
